package com.Kali.billingSoftware.io;

public enum PaymentMethod {
    CASH,UPI
}
