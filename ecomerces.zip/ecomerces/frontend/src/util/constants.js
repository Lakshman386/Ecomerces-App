export const AppConstants={
    RAZORPAY_KEY_ID:"rzp_test_Elno6XPbuhLp7o"
}