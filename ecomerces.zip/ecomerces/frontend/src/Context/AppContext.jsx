import React, { createContext, useEffect, useState } from 'react'
import { fetchCategories} from '../Service/CategoryService';
import { featchItems } from '../Service/ItemService';

export const AppContext=createContext(null);
export function AppContextProvider(props){
    const[itemsData,setItemsData]=useState([])
    const [categories,setCategories]=useState([])
    const[auth,setAuth]=useState({token:localStorage.getItem("token")||null,role:localStorage.getItem('role')||null})
    const[cartItems,setCartItems]=useState([])
    useEffect(()=>{
        async function loadData(){
            const response=await fetchCategories();
            const itemResponse=await featchItems();
            setCategories(response.data);
            setItemsData(itemResponse.data);            
        }
        loadData();
    },[auth])
    const clearCart=()=>{
        setCartItems([])
    }

    const addToCart=(item)=>{
        const existingItem=cartItems.find(cartItem=>cartItem.name===item.name)
        if(existingItem){
            setCartItems(cartItems.map(cartItem=>cartItem.name===item.name?{...cartItem,quantity:cartItem.quantity+1}:cartItem))
        }
        else{
            setCartItems([...cartItems,{...item,quantity:1}])
        }
    }
    const removeFromCart=(itemId)=>{
setCartItems(cartItems.filter(item=>(item.itemId!==itemId)))
    }
    const updateQuantity=(itemId,newQuantity)=>{
setCartItems(cartItems.map(item=>item.itemId===itemId?{...item,quantity:newQuantity}:item))
    }

   
    const contextValue={
        categories,
        setCategories,
        auth,
        setAuth,
        itemsData,
        setItemsData,
        addToCart,
        cartItems,
        removeFromCart,
        updateQuantity,
        clearCart
    }
    
    return <AppContext.Provider value={contextValue}>{props.children}</AppContext.Provider>

}
