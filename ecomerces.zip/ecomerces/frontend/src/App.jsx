import { Route, Routes, useLocation, Navigate } from 'react-router-dom'
import './App.css'
import MenuBar from './MenuBar/MenuBar'
import DashBoard from './pages/DashBoard/DashBoard'
import Explore from './pages/Explore/Explore'
import ManageCategory from './pages/ManageCategory/ManageCategory'
import ManageItems from './pages/ManageItems/ManageItems'
import ManageUsers from './pages/ManageUsers/ManageUsers'
import { Toaster } from 'react-hot-toast';
import Login from './pages/Login/Login'
import OrderHistory from './pages/OrderHistory/OrderHistory'
import { useContext } from 'react'
import { AppContext } from './Context/AppContext'
import NotFound from './pages/NotFound/NotFound'


function App() {
const location=useLocation();
const{auth}=useContext(AppContext);
const LoginRoute=({element})=>{
  if(auth.token){
    return <Navigate to="/dashboard" replace/>
  }
  return element;
}

const ProtectedRoute=({element,allowedRoles})=>{  
  if(!auth.token){
    return <Navigate to='/login' replace/>
  }
  if(allowedRoles && !allowedRoles.includes(auth.role)){
    return <Navigate to='/dashboard' replace/>
  }
  return element;
}
  return (
    <>
      {location.pathname !== "/login" && <MenuBar/>}
      <Toaster></Toaster>
      <Routes>
        <Route path='/' element={<DashBoard></DashBoard>}></Route>
        <Route path='/DashBoard' element={<DashBoard></DashBoard>}></Route>
        <Route path="/Explore" element={<Explore></Explore>}></Route>
        <Route path="/ManageCategory" element={<ProtectedRoute element={<ManageCategory/>} allowedRoles={['ROLE_ADMIN']}/>}></Route>
        <Route path="/ManageItems" element={<ProtectedRoute element={<ManageItems/>}allowedRoles={['ROLE_ADMIN']}/>}></Route>
        <Route path="/ManageUsers" element={<ProtectedRoute element={<ManageUsers/>} allowedRoles={['ROLE_ADMIN']}/>}></Route>
        <Route path='/OrderHistory' element={<OrderHistory/>}></Route>
        <Route path='/login' element={<LoginRoute element={<Login/>} />}></Route>
        <Route path='*' element={<NotFound/>}></Route>
      </Routes>
    </>
  )
}

export default App
