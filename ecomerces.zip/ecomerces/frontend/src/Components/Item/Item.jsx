import React, { useContext } from 'react'
import './Item.css'
import { AppContext } from '../../Context/AppContext'

export default function Item({itemName,itemPrice,itemImage,itemId}) {
  const {addToCart}=useContext(AppContext)
  const handleCart=()=>{
   addToCart({ name:itemName,
    price:itemPrice,
    itemId:itemId,
    quantity:1})
  }
  return (
    <div className="p-3 bg-dark rounded shadow-sm h-100 d-flex align-items-center item-card">
      <div style={{position:"relative", marginRight:"15px"}}>
        <img src={itemImage} style={{height:'60px',width:'60px', borderRadius:'10px'}} alt={itemName} />
      </div>

      <div className="flex-Grow-1 ms-2">
        <h6 className="mb-1 text-light" style={{fontSize:'12px', fontWeight:'bold'}}>{itemName}</h6>
        <p className="mb-0 fw-bold text-light" >&#8377;{itemPrice}</p>
      </div>

      <div style={{height:'100%'}} className="d-flex flex-column justify-content-between align-items-center ms-3">
        <i className="bi bi-cart-plus fs-4 text-warning"></i>
        <button className="bt btn-success btn-sm" onClick={handleCart}>
          <i className="bi bi-plus"></i>
        </button>
      </div>
    </div>
  )
}
