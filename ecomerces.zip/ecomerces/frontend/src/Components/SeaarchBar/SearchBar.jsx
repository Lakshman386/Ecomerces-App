import React, { useState } from 'react'

export default function SearchBar({onSearch}) {
    const [searchText,setsearchText]=useState("")

    function handleInputChange(e){
        const text=e.target.value
       setsearchText(text)
       onSearch(text)

    }
  return (
    <div className="input-group mb-3">
        <input type="text" value={searchText} onChange={handleInputChange} className="form-control" placeholder='Search items..' />
        <span className="input-group-text bg-warning">
            <i className="bi bi-search"></i>
        </span>
    </div>
  )
}
