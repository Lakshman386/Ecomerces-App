import React, { useState } from 'react'
import { useContext } from 'react'
import {AppContext} from '../../Context/AppContext'
import assets from '../../assets/assets.js'
import toast from 'react-hot-toast'
import {addItem} from '../../Service/ItemService'

export default function ItemForm() {
    const[loading,setLoading]=useState(false)
    const[image,setImage]=useState(false)
    const{categories,setItemsData,itemsData,setCategories}=useContext(AppContext)
    const[data,setData]=useState({
        name:"",
        categoryId:"",
        price:"",
        description:""
    })

    const onChangeHandler=async(e)=>{
        const name=e.target.name;
        const value=e.target.value;
        setData((data)=>({...data,[name]:value}))
    }

    const onSubmitHandler=async(e)=>{
        e.preventDefault();
        setLoading(true)
        const formData=new FormData();
        formData.append('item',JSON.stringify(data));
        formData.append('file',image);
        for (let [key, value] of formData.entries()) {
  console.log(`${key}:`, value);
}
        try{
            if(!image){
                toast.error("select Image")
                return;
            }
            const response=await addItem(formData)
            if(response.status===200||response.status===201){
                setItemsData([...itemsData,response.data])
                //update the category state
                setCategories((prevData)=>prevData.map((category)=>category.categoryId===data.categoryId?{...category,items:category.items+1}:category))
                toast.success("Item Added")
                setData({
                    name:"",
                    description:"",
                    price:"",
                    categoryId:""
                })
            }
            else{
                toast.error("Unable to add Item")
            }
        }
        catch(e){
            console.error(e)
             toast.error("Unable to add Item")
        }
        finally{
            setLoading(false)
        }
    }
  return (
    <div className="item-form-container" style={{height:'100vh',overflowY:'auto',overflowX:'hidden'}} >
        <div className=" mx-2 mt-2">
            <div className="row">
                <div className="card col-md-12 form-container">
                    <div className="card-body">
                        <form onSubmit={onSubmitHandler}>
                            <div className="mb-3">
                                <label htmlFor="image" className="form-label">
                                    <img src={image?URL.createObjectURL(image):assets().upload} alt="" width={48} />
                                </label>
                                <input type="file" name="image" id="image" onChange={e=>setImage(e.target.files[0])} className="form-control" hidden />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="name" className="form-label">Name</label>
                                <input type="text" name="name" id="name" className="form-control"
                                placeholder="Item Name" onChange={onChangeHandler} value={data.name} required/>
                            </div>

                            <div className="mb-3">
                                <label htmlFor="category" className="form-label">Category</label>
                                <select name="categoryId" id="category" onChange={onChangeHandler} value={data.categoryId} className='form-control' required>
                                    <option value="">SELECT CATEGORY</option>
                                    {categories.map((category,index)=>(
                                        <option key={index} value={category.categoryId}>{category.name}</option>
                                    ))}                             
                                </select>
                            </div>

                            <div className="mb-3">
                                <label htmlFor="price" className='form-label'>Price</label>
                                <input required type="number" name='price' id='price'onChange={onChangeHandler} value={data.price} className='form-control' placeholder='&#8377;200.00' />
                            </div>
                            
                            <div className="mb-3">
                                <label htmlFor="description" className="form-label">Description</label>
                                <textarea
                                rows={8} type="text" name="description" id="name" onChange={onChangeHandler} value={data.description} className="form-control"
                                placeholder="Category Name" />
                            </div>

                            <button type="submit" className="btn btn-warning w-100" disabled={loading}>{loading?"Saving...":"Save"}</button>
                            
                        </form>                      
                        
                    </div>
                </div>
            </div>
         </div>
    </div>
  )
}
