import React, { useState } from 'react'
import toast from 'react-hot-toast';
import {addUser} from '../../Service/UserService'

export default function UserForm({ setUsers }) {
    const [loading, setLoading] = useState(false)
    const [data, setData] = useState({
        name: '',
        email: '',
        password: '',
        role: 'ROLE_USER'
    })
    function onChangeHandler(e) {
        const name = e.target.name;
        const value = e.target.value;
        setData(data => ({ ...data, [name]: value }))
    }

    async function handleSubmit(e) {
        e.preventDefault();
        setLoading(true)
        try {
            const response = await addUser(data);
            setUsers(prev => [...prev, response.data])
            toast.success("User Added successfully")
            setData({
                name: '',
                email: '',
                password: '',
                role: 'ROLE_USER'
            })
        }
        catch (e) {
            console.log(e)
            toast.error("Error adding user")
        }
        finally {
            setLoading(false)
        }

    }

    return (
        <div className=" mx-2 mt-2">
            <div className="row">
                <div className="card col-md-12 form-container">
                    <div className="card-body">
                        <form onSubmit={handleSubmit}>

                            <div className="mb-3">
                                <label htmlFor="name" className="form-label">Name</label>
                                <input required type="text" name="name" id="name" value={data.name} onChange={onChangeHandler} className="form-control"
                                    placeholder="Corinne" />
                            </div>

                            <div className="mb-3">
                                <label htmlFor="email" className="form-label">E-Mail</label>
                                <input required type="text" name="email" id="email" value={data.email} onChange={onChangeHandler} className="form-control"
                                    placeholder="Your name@gmail.com" />
                            </div>

                            <div className="mb-3">
                                <label htmlFor="password" className="form-label">Password</label>
                                <input required type="text" name="password" id="password" value={data.password} onChange={onChangeHandler} className="form-control"
                                    placeholder="****************" />
                            </div>

                            <button type="submit" className="btn btn-warning w-100" disabled={loading}>{loading ? 'Saving.....' : 'Save'}</button>

                        </form>

                    </div>
                </div>
            </div>
        </div>
    )
}
