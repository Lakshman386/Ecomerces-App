import React, { useContext } from 'react'
import './CartItems.css'
import { AppContext } from '../../Context/AppContext'

export default function CartItems() {
  const { cartItems, removeFromCart, updateQuantity } = useContext(AppContext);
  
  return (
    <div className="p-3 h-100 overflow-y-auto">
      {cartItems.length === 0 ? (
        <p className="text-light">Cart is Empty</p>
      ) :
        (<div className="cart-items-list">
          {cartItems.map((item, index) => (
            <div key={index} className="cart-item mb-3 p-3 bg-dark rounded">
              <div className="d-flex justify-content-between align-item-center mb-2">
                <h6 className="mb-0 text-light">{item.name}</h6>
                <p className="mb-0 text-light">
                  &#8377;{(item.price * item.quantity).toFixed(2)}
                </p>
              </div>
              <div className="d-flex justify-content-between align-item-center">
                <div className="d-flex align-item-center gap-2">
                  <button onClick={() => updateQuantity(item.itemId, item.quantity - 1)}
                    disabled={item.quantity === 1} className="btn btn-danger btn-sm">
                    <i className="bi bi-dash"></i>
                  </button>
                  <span className="text-light">{item.quantity}</span>
                  <button onClick={() => updateQuantity(item.itemId, item.quantity + 1)} className="btn btn-primary btn-sm">
                    <i className="bi bi-plus"></i>
                  </button>                  
                </div>
                <button onClick={() => removeFromCart(item.itemId)} className="btn btn-danger btn-sm" style={{ width: 'auto' }}>
                    <i className="bi bi-trash"></i>
                  </button>
              </div>
            </div>
          ))}
        </div>)}
    </div>

  )
}
