import React from 'react'
import './CustomerForm.css'

export default function CustomerForm({customerName,setCustomerName,mobileNumber,setMobileNumber}) {
  return (
    <div className="p-2">
      <div className="mb-1">
        <div className="d-flex align-items-center gap-2">
          <label htmlFor="customerName" className="form-label col-4">Customer Name</label>
          <input required type="text" id='customerName' className="form-Control form-control-sm"
          value={customerName} onChange={e=>setCustomerName(e.target.value)} />
        </div>
      </div>
      <div className="mb-2">
        <div className="d-flex align-items-center gap-2">
          <label htmlFor="mobileNumber" className="form-label col-4">Mobile Number</label>
          <input required type="number" id='mobileNumber' className="form-Control form-control-sm" value={mobileNumber}
          onChange={e=>setMobileNumber(e.target.value)} />
        </div>
      </div>
    </div>
  )
}
