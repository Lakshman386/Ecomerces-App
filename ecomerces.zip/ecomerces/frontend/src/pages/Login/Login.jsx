import toast from 'react-hot-toast';
import './Login.css';

import React, { useContext, useState } from 'react'
import { login } from '../../Service/AuthService';
import { useNavigate } from 'react-router-dom';
import { AppContext } from '../../Context/AppContext';

export default function Login() {
    const nav=useNavigate()
    const{setAuth}=useContext(AppContext);
    const[loading,setLoading]=useState(false)
    const[data,setData]=useState({
        email:'',
        password:''
    });
    function onChangeHandler(e){
        const name=e.target.name
        const value=e.target.value
        setData(data=>({...data,[name]:value}));
    }
    async function submitHandler(e){
        e.preventDefault();
        setLoading(true)
        try{
            const response=await login(data);
            if(response.status===200){
                toast.success("Login Success..")
                localStorage.setItem('token',response.data.token)
                localStorage.setItem('role',response.data.role);
                setAuth({token:response.data.token,role:response.data.role});
                nav('/dashboard')
            }
        }
        catch(e){
            console.log(e)
            toast.error("Email oor Password is Invalid")
        }
        finally{
            setLoading(false);
        }
    }

  return (
    <div className="bg-light d-flex align-items-center justify-content-center vh-100 login-background">
        <div className="card shadow-lg w-100" style={{maxWidth:'480px'}}>
            <div className="card-body">
                <div className="text-center">
                    <h1 className="card-title">Sign in</h1>
                    <p className="card-text text-muted">
                        Sign in below to access your account
                    </p>
                </div>
                <div className="mt-4">
                    <form action="submit" onSubmit={submitHandler}>
                        <div className="mb-4">
                            <label htmlFor="email" className='form-label text-muted'>Email address</label>
                            <input type="text" name='email'value={data.email} onChange={onChangeHandler} id='email'placeholder='name@abc.com' className='form-control' />
                        </div>
                        <div className="mb-4">
                            <label htmlFor="password" className='form-label text-muted'>Password</label>
                            <input type="password" name='password' value={data.password} onChange={onChangeHandler} id='password'placeholder='**********' className='form-control' />
                        </div>
                        <div className="d-grid">
                            <button type="submit" disabled={loading} className="btn btn-dark btn-lg">{loading?"Please Wait...":'SignIn'}</button>
                        </div>
                        
                    </form>
                </div>
            </div>
        </div>
    </div>
  )
}
