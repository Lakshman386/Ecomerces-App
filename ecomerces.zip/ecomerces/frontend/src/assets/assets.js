import logo from './logo.png';
import upload from './upload.png'
import login from './bgImg.jpg'
import profile from './profile.png';
import device from './device.png'

export default function assets(){
    return {
        logo,upload,login,profile,device
    }
}
