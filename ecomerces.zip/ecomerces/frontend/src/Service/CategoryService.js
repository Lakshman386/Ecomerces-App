import axios from "axios";

export const addCategory=async(category)=>{
    return await axios.post('http://localhost:8080/api/v1.0/categories/admin/addCategory',category,{
        headers:{
            Authorization:`Bearer ${localStorage.getItem('token')}`
        }
    });
}

export async function deleteCategory(categoryId){
    return await axios.delete(`http://localhost:8080/api/v1.0/categories/admin/delete/${categoryId}`,{
        headers:{
            Authorization:`Bearer ${localStorage.getItem('token')}`
        }
    });
}
export async function fetchCategories(){
    return await axios.get('http://localhost:8080/api/v1.0/categories/getAllCategories',{
        headers:{
            Authorization:`Bearer ${localStorage.getItem('token')}`
        }
    });
}